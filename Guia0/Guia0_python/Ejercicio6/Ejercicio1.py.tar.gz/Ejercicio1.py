# Programa Ejercico 1 _ Guia 1 2017 ; (c) Mariano Forti
# numpy se instala en ubuntu como python-numpy
#matplotlib se instala en ubuntu como python-matplotlib
from numpy import * 
from matplotlib.pyplot import *

def misplines(X,Y,fun_name):
    """
    Esto es un comentario multilinea
    def es la palabra clave para las funciones. las indentaciones son las que marcan comienzo y fin
    de funciones y otros statements. 
    """

    N=len(X)
    h=diff(z).astype(float)  # diff se importa de numpy.
    print h
    A=matrix(identity(N)).astype(float)    # matrix se importa de numpy. las operaciones se interpretan entre matrices. 
    YY=matrix(zeros([N,1])).astype(float)
    for i in linspace(1,N-2,N-1).astype(int):
        """
        como antes, la indentacion marca la pertenencia a los statements. 
        crear estos vectores sin el + adelante crea una especie de puntero. para que los valores se guarden de verdad 
        en memoria hay que asignar con el mas. 

        """
        A[i,[i-1,i,i+1]]=+array([h[i-1],2*(h[i]+h[i-1]),h[i]]) # Los rangos no incluyen el limite superior. 
                                                               # por eso i-1:i+1 no funciona!
        YY[i]=+3.0*( ( T[i+1]-T[i])/h[i] - (T[i]-T[i-1])/h[i-1] ) 
                                  
 
    B=linalg.solve(A,YY)  # linalg se importa de numpy. linalg.solve resuelve el sistema lineal AA*B=YY.
    a=zeros([N-1,1])
    c=zeros([N-1,1])
    b=zeros([N-1,1])
    d=zeros([N-1,1])
    
    for i in linspace(0,N-2,N-1).astype(int):
        a[i]=(1.0/3.0) * ( B[i+1] - B[i] ) / h[i]
        c[i]=(T[i+1]-T[i])/h[i] - B[i]*h[i] - a[i]*( h[i]**2 )
        b[i]=B[i,0]
        d[i]=Y[i]

#    guardar en archivos (concatenacion)
    afile='a'+fun_name+'.txt'
    bfile='b'+fun_name+'.txt'
    cfile='c'+fun_name+'.txt'
    dfile='d'+fun_name+'.txt'

    savetxt(afile,a)
    savetxt(bfile,b)
    savetxt(cfile,c)
    savetxt(dfile,d)


    # devolver la salida y terminar la funcion:
    return a,b,c,d 


z,T = loadtxt('DATA.txt',unpack=True) # loadtxt se importa de numpy
    
print "Z = ", z
print "T = ", T


N=len(z)
print "N = ", N


a,b,c,d = misplines(z,T,'funcion')
print a
print b
print c
print d

# el grafico se va armando sin mostrar hasta que se pide explicitamente.
# pyplot.plot funciona como el plot de matlab , grafica vectores. 
# notar que se importa de matplotlib.pyplot
plot(z,T,'ok',markersize=15)
for i in linspace(0,N-2,N-1).astype(int):
    zi=linspace(z[i],z[i+1],10).astype(float)
    Ti=a[i]*(zi-z[i])**3+b[i]*(zi-z[i])**2+c[i]*(zi-z[i]) +d[i]
    plot(zi,Ti,'--k')  # plot es importada de matplotlib.pyplot

# show simplemente dibuja el grafico que fue cargado
show()


